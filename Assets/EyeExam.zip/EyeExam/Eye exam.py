import tkinter
from tkinter import *
import random
import time
import os, sys
window = tkinter.Tk()

window.attributes('-fullscreen', True)

list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)



def get_letters():
    selection_list = []
    for i in range(7):
        selection_list.append(random.choice(list)+'  ')
    return selection_list

level_1 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 100, 'bold'), justify = 'center')
level_1.place(x = 960, y = 100, anchor = 'center')


level_2 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 70, 'bold'), justify = 'center')
level_2.place(x = 940, y = 300, anchor = 'center')

level_3 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 50, 'bold'), justify = 'center')
level_3.place(x = 940, y = 500, anchor = 'center')

level_4 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 30, 'bold'), justify = 'center')
level_4.place(x = 910, y = 650, anchor = 'center')

level_5 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 20, 'bold'), justify = 'center')
level_5.place(x = 900, y = 750, anchor = 'center')

level_6 = Label(window, text = ''.join(get_letters()),  font = ('verdana', 12, 'bold'), justify = 'center')
level_6.place(x = 900, y = 830, anchor = 'center')

exit_text = Label(window, text = 'Press Alt + F4 to close',  font = ('verdana', 12, 'bold'), justify = 'center')
exit_text.place(x = 120, y = 1040, anchor = 'center')
window.iconbitmap(resource_path("show.ico"))

































window.mainloop()

