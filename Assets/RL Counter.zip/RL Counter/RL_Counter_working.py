import tkinter
from tkinter import *
from tkinter import ttk
import time
import pyperclip
import RL_put_togetherer as rl
import sys, os
list = []

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

window = tkinter.Tk()


# Button Programming
def Win():
    list.append('W ')
    update()



def Lose():
    list.append('L ')
    update()

def clear():
    list.clear()
    w_or_l_display.config(text='')
    update()

def undo():
    if len(list) != 0:
        list.pop()
        update()
    else:
        pass

def update():
    w_or_l_display.config(text=''.join(list), justify = 'center')
    if len(list) > 16:
        warning.config(text='Warning, Discord formatting only supports up to 16 games', justify = 'center')
    if len(list) <= 16:
        warning.config(text='', justify = 'center')


def copy():
    pyperclip.copy(rl.put_together(list))
    print(list)

# Program design
window.title('Kakapos Ranked Result Counter')
window.geometry('370x200')
window.resizable(width = False, height = False)
window.configure(bg = '#2a2a2b')
window.iconbitmap(resource_path("misatoburgerking.ico"))







InstructionText = Label(window, text = 'Please press the "Win" or "Loss" button depending \n on the outcome of the match', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', justify = 'center').place(x = 20, y =10)

WinButton = Button(window, text = 'Win', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', command = Win).place(x = 175, y = 60)

LoseButton = Button(window, text = 'Loss', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', command = Lose).place(x = 220, y = 60)

ClearButton = Button(window, text = 'Clear', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', command = clear).place(x = 120, y = 60)

RemoveButton = Button(window, text = 'Undo', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', command = undo).place(x = 140, y = 160)

CopyButton = Button(window, text = 'Copy', font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', command = copy).place(x = 200, y = 160)

w_or_l_display = Label(window, text = '',  font = ('verdana', 10, ''), bg = '#2a2a2b', fg = 'white', justify = 'center')
w_or_l_display.place(x = 195, y = 120, anchor = 'center')

warning = Label(window, text = '',  font = ('verdana', 8, ''), bg = '#2a2a2b', fg = 'white', justify = 'center')
warning.place(x = 185, y = 140, anchor = 'center')


















window.mainloop()