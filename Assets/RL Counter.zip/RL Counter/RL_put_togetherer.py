import datetime




def put_together(list_of_w):
    d = datetime.datetime.today()
    line_0 = '```'
    line_1 = 'Date: ' + str(d.day) + '/' + str(d.month) + '/' + str(d.year)
    line_2_list = []
    line_3_list = []
    line_4 = '```'
    count = 1
    for entry in list_of_w:
        line_2_list.append('Game '+str(count)+'  ')
        for char in entry:
            if count < 10:
                if char.lower() == 'w':
                    line_3_list.append('W       ')
                elif char.lower() == 'l':
                    line_3_list.append('L       ')
            else:
                if char.lower() == 'w':
                    line_3_list.append('W        ')
                elif char.lower() == 'l':
                    line_3_list.append('L        ')

        count += 1
    line_2 = ''.join(line_2_list)
    line_3 = ''.join(line_3_list)
    return str(line_0+'\n'+line_1+'\n'+line_2+'\n'+line_3+'\n'+line_4)




