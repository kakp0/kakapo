dict = open('wordle_list.txt')
from PyQt5.QtWidgets import *
from PyQt5 import QtCore
import sys
# may want to switch between words.txt and dictionary.txt
wordle_list = []

for line in dict:
    if len(line) - 1 == 5:
        line = line[:-1]

        wordle_list.append(line.lower())
undo_list = []

# window making
app = QApplication([])
window = QWidget()

class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):

        QMainWindow.__init__(self)
        QScrollArea.__init__(self, *args, **kwargs)
        self.app = QApplication(sys.argv)
        self.setWindowTitle("Wordle Solver")

        # window size
        self.setFixedSize(390, 200)

        # textbox's?

        self.textbox = QLineEdit(self)
        self.textbox.move(50, 50)
        self.textbox.resize(50, 50)
        self.textbox.setStyleSheet('color: white; background-color: #525252')
        self.textbox.setAlignment(QtCore.Qt.AlignCenter)
        self.f = self.textbox.font()
        self.f.setPointSize(27)
        self.textbox.setFont(self.f)
        self.textbox.setMaxLength(1)
        self.textbox.setFocus()
        self.textbox.textChanged.connect(lambda: self.textbox2.setFocus())

        self.cycle_value = 0
        self.cycle = QPushButton(self)
        self.cycle.setText("Change")
        self.cycle.move(50, 110)
        self.cycle.resize(50, 30)

        self.textbox2 = QLineEdit(self)
        self.textbox2.move(110, 50)
        self.textbox2.resize(50, 50)
        self.textbox2.setFont(self.f)
        self.textbox2.setStyleSheet('color: white; background-color: #525252')
        self.textbox2.setAlignment(QtCore.Qt.AlignCenter)
        self.textbox2.setMaxLength(1)
        self.textbox2.textChanged.connect(lambda: self.textbox3.setFocus())

        self.cycle_value2 = 0
        self.cycle2 = QPushButton(self)
        self.cycle2.setText("Change")
        self.cycle2.move(110, 110)
        self.cycle2.resize(50, 30)



        self.textbox3 = QLineEdit(self)
        self.textbox3.move(170, 50)
        self.textbox3.resize(50, 50)
        self.textbox3.setFont(self.f)
        self.textbox3.setStyleSheet('color: white; background-color: #525252')
        self.textbox3.setAlignment(QtCore.Qt.AlignCenter)
        self.textbox3.setMaxLength(1)
        self.textbox3.textChanged.connect(lambda: self.textbox4.setFocus())

        self.cycle_value3 = 0
        self.cycle3 = QPushButton(self)
        self.cycle3.setText("Change")
        self.cycle3.move(170, 110)
        self.cycle3.resize(50, 30)

        self.textbox4 = QLineEdit(self)
        self.textbox4.move(230, 50)
        self.textbox4.resize(50, 50)
        self.textbox4.setFont(self.f)
        self.textbox4.setStyleSheet('color: white; background-color: #525252')
        self.textbox4.setAlignment(QtCore.Qt.AlignCenter)
        self.textbox4.setMaxLength(1)
        self.textbox4.textChanged.connect(lambda : self.textbox5.setFocus())


        self.cycle_value4 = 0
        self.cycle4 = QPushButton(self)
        self.cycle4.setText("Change")
        self.cycle4.move(230, 110)
        self.cycle4.resize(50, 30)

        self.textbox5 = QLineEdit(self)
        self.textbox5.move(290, 50)
        self.textbox5.resize(50, 50)
        self.textbox5.setFont(self.f)
        self.textbox5.setStyleSheet('color: white; background-color: #525252')
        self.textbox5.setAlignment(QtCore.Qt.AlignCenter)
        self.textbox5.setMaxLength(1)
        self.textbox5.textChanged.connect(lambda: self.textbox.setFocus())

        self.cycle_value5 = 0
        self.cycle5 = QPushButton(self)
        self.cycle5.setText("Change")
        self.cycle5.move(290, 110)
        self.cycle5.resize(50, 30)

        # Button
        self.button1 = QPushButton(self)
        self.button1.setText("Search")
        self.button1.move(170, 150)
        self.button1.resize(50, 30)

        self.button1.clicked.connect(self.clicky)

        #cycle button functions
        self.cycle.clicked.connect(self.cycle_fun)
        self.cycle2.clicked.connect(self.cycle_fun2)
        self.cycle3.clicked.connect(self.cycle_fun3)
        self.cycle4.clicked.connect(self.cycle_fun4)
        self.cycle5.clicked.connect(self.cycle_fun5)





    def clicky(self):
        print(self.textbox.text(),self.textbox2.text(),self.textbox3.text(),self.textbox4.text(),self.textbox5.text())
        print(self.cycle_value, self.cycle_value2, self.cycle_value3, self.cycle_value4, self.cycle_value5)

        if self.cycle_value == 0:
            self.search('2',self.textbox.text(),1)
        if self.cycle_value == 1:
            self.search('6',self.textbox.text(),1)
            self.search('1', self.textbox.text(), 1)
        if self.cycle_value == 2:
            self.search('5', self.textbox.text(), 1)

        if self.cycle_value2 == 0:
            self.search('2',self.textbox2.text(),2)
        if self.cycle_value2 == 1:
            self.search('6',self.textbox2.text(),2)
            self.search('1', self.textbox2.text(), 2)
        if self.cycle_value2 == 2:
            self.search('5', self.textbox2.text(), 2)

        if self.cycle_value3 == 0:
            self.search('2',self.textbox3.text(),3)
        if self.cycle_value3 == 1:
            self.search('6',self.textbox3.text(),3)
            self.search('1', self.textbox3.text(), 3)
        if self.cycle_value3 == 2:
            self.search('5', self.textbox3.text(), 3)

        if self.cycle_value4 == 0:
            self.search('2',self.textbox4.text(),4)
        if self.cycle_value4 == 1:
            self.search('6',self.textbox4.text(),4)
            self.search('1', self.textbox4.text(), 4)
        if self.cycle_value4 == 2:
            self.search('5', self.textbox4.text(), 4)

        if self.cycle_value5 == 0:
            self.search('2',self.textbox5.text(),5)
        if self.cycle_value5 == 1:
            self.search('6',self.textbox5.text(),5)
            self.search('1', self.textbox5.text(), 5)
        if self.cycle_value5 == 2:
            self.search('5', self.textbox5.text(), 5)

        print(self.wordle_list_results)

        self.textbox.setText('')
        self.textbox2.setText('')
        self.textbox3.setText('')
        self.textbox4.setText('')
        self.textbox5.setText('')

        self.textbox.setStyleSheet('color: white; background-color: #525252')
        self.cycle_value = 0

        self.textbox2.setStyleSheet('color: white; background-color: #525252')
        self.cycle_value2 = 0

        self.textbox3.setStyleSheet('color: white; background-color: #525252')
        self.cycle_value3 = 0

        self.textbox4.setStyleSheet('color: white; background-color: #525252')
        self.cycle_value4 = 0

        self.textbox5.setStyleSheet('color: white; background-color: #525252')
        self.cycle_value5 = 0



# cycle functions for each of the cycle buttons

    def cycle_fun(self):
        if self.cycle_value == 0:
            self.textbox.setStyleSheet('color: white; background-color: #ebb734')
            self.cycle_value += 1

        elif self.cycle_value == 1:
            self.textbox.setStyleSheet('color: white; background-color: #2ab844')
            self.cycle_value += 1

        elif self.cycle_value == 2:
            self.textbox.setStyleSheet('color: white; background-color: #525252')
            self.cycle_value = 0


    def cycle_fun2(self):
        if self.cycle_value2 == 0:
            self.textbox2.setStyleSheet('color: white; background-color: #ebb734')
            self.cycle_value2 += 1

        elif self.cycle_value2 == 1:
            self.textbox2.setStyleSheet('color: white; background-color: #2ab844')
            self.cycle_value2 += 1

        elif self.cycle_value2 == 2:
            self.textbox2.setStyleSheet('color: white; background-color: #525252')
            self.cycle_value2 = 0

    def cycle_fun3(self):
        if self.cycle_value3 == 0:
            self.textbox3.setStyleSheet('color: white; background-color: #ebb734')
            self.cycle_value3 += 1

        elif self.cycle_value3 == 1:
            self.textbox3.setStyleSheet('color: white; background-color: #2ab844')
            self.cycle_value3 += 1

        elif self.cycle_value3 == 2:
            self.textbox3.setStyleSheet('color: white; background-color: #525252')
            self.cycle_value3 = 0

    def cycle_fun4(self):
        if self.cycle_value4 == 0:
            self.textbox4.setStyleSheet('color: white; background-color: #ebb734')
            self.cycle_value4 += 1

        elif self.cycle_value4 == 1:
            self.textbox4.setStyleSheet('color: white; background-color: #2ab844')
            self.cycle_value4 += 1

        elif self.cycle_value4 == 2:
            self.textbox4.setStyleSheet('color: white; background-color: #525252')
            self.cycle_value4 = 0

    def cycle_fun5(self):
        if self.cycle_value5 == 0:
            self.textbox5.setStyleSheet('color: white; background-color: #ebb734')
            self.cycle_value5 += 1

        elif self.cycle_value5 == 1:
            self.textbox5.setStyleSheet('color: white; background-color: #2ab844')
            self.cycle_value5 += 1

        elif self.cycle_value5 == 2:
            self.textbox5.setStyleSheet('color: white; background-color: #525252')
            self.cycle_value5 = 0





    def search(self, mode, letter, pos):
        global wordle_list

        self.wordle_list_results = []

        inputi = mode
        if letter != '':
            if inputi == '2':
                undo_list = list(wordle_list)
                nonolist = []

                for char in letter:
                    nonolist = []
                    for word in wordle_list:

                        if char in word:
                            nonolist.append(word)



                    for word in nonolist:
                        wordle_list.remove(word)
                self.wordle_list_results = wordle_list

            if inputi == '1':
                nonolist = []
                undo_list = list(wordle_list)
                for char in letter:
                    nonolist = []
                    for word in wordle_list:

                        if char not in word:
                            nonolist.append(word)

                    for word in nonolist:
                        wordle_list.remove(word)
                self.wordle_list_results = wordle_list

            if inputi == '3':
                ininputi = input("enter letter that the word starts with: ")
                nonolist = []
                undo_list = list(wordle_list)

                for char in ininputi:
                    nonolist = []
                    for word in wordle_list:

                        if word[0] != char:
                            nonolist.append(word)

                    for word in nonolist:
                        wordle_list.remove(word)
                print(wordle_list)
                print()


            if inputi == '4':
                ininputi = input("enter letter that the word ends with: ")
                nonolist = []
                undo_list = list(wordle_list)

                for char in ininputi:
                    nonolist = []
                    for word in wordle_list:

                        if word[-1] != char:
                            nonolist.append(word)

                    for word in nonolist:
                        wordle_list.remove(word)
                self.wordle_list_results = wordle_list

            if inputi == '5':
                nonolist = []
                undo_list = list(wordle_list)
                char = letter

                number = pos

                nonolist = []
                for word in wordle_list:

                    if word[int(number)-1] != char:
                        nonolist.append(word)

                for word in nonolist:
                    wordle_list.remove(word)
                self.wordle_list_results = wordle_list


            if inputi == '6':
                nonolist = []

                undo_list = list(wordle_list)
                char = letter

                number = pos

                nonolist = []
                for word in wordle_list:

                    if word[int(number)-1] == char:
                        nonolist.append(word)

                for word in nonolist:
                    wordle_list.remove(word)
                self.wordle_list_results = wordle_list

            if inputi.lower() == 'undo':
                wordle_list = undo_list
                self.wordle_list_results = wordle_list

mainWin = MainWindow()
mainWin.show()
sys.exit( app.exec_() )